"""Interfaz de escritorio ArgosIA."""
